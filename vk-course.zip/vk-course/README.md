# VK Automation Course

Интерактивное пошаговое обучение автоматизации публикаций ВКонтакте.

## Деплой на Vercel (5 минут)

1. Загрузи эту папку на GitHub
2. Зайди на vercel.com → New Project → Import из GitHub
3. Нажми Deploy — Vercel сам определит настройки
4. Получи ссылку вида `твой-проект.vercel.app`

## Локальный запуск

```bash
npm install
npm start
```

Открой http://localhost:3000
