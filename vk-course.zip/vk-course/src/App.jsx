import { useState, useEffect, useRef } from "react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const STEPS = {
  start: {
    id: "start",
    type: "question",
    phase: "🔍 Диагностика",
    title: "Давай начнём с главного",
    text: "Есть ли у тебя уже опыт работы с Python?",
    options: [
      { label: "Нет, я новичок", value: "no_python", icon: "🌱" },
      { label: "Базовый — запускал скрипты, понимаю синтаксис", value: "basic_python", icon: "⚡" },
      { label: "Уверенный — пишу сам, знаю pip, venv", value: "advanced_python", icon: "🚀" },
    ],
  },

  // ── ВЕТКА: НЕТ PYTHON ──────────────────────────────────────────────────────
  no_python: {
    id: "no_python",
    type: "lesson",
    phase: "🛠 Подготовка",
    title: "Шаг 1. Устанавливаем Python",
    text: `Без Python никуда — это основа всей автоматизации. Процесс простой.`,
    steps: [
      { n: 1, text: "Открой сайт **python.org/downloads**" },
      { n: 2, text: "Скачай Python **3.11** или новее (кнопка «Download Python»)" },
      { n: 3, text: "При установке **обязательно** поставь галочку «Add Python to PATH»" },
      { n: 4, text: "Открой командную строку (Win+R → cmd) и введи: `python --version`" },
      { n: 5, text: "Если видишь `Python 3.11.x` — всё готово ✅" },
    ],
    tip: "💡 Если видишь ошибку «python не является внутренней командой» — переустанови Python, не забыв про галочку PATH.",
    next: "no_python_editor",
  },

  no_python_editor: {
    id: "no_python_editor",
    type: "lesson",
    phase: "🛠 Подготовка",
    title: "Шаг 2. Редактор кода",
    text: "Нужен удобный редактор, чтобы писать и запускать скрипты.",
    steps: [
      { n: 1, text: "Скачай **VS Code** на code.visualstudio.com" },
      { n: 2, text: "Установи расширение **Python** (Extensions → поиск «Python» → Install)" },
      { n: 3, text: "Создай папку `vk_bot` на рабочем столе — это твой рабочий проект" },
      { n: 4, text: "Открой папку в VS Code: File → Open Folder" },
    ],
    tip: "💡 VS Code подсвечивает синтаксис, показывает ошибки и позволяет запускать скрипты прямо из редактора.",
    next: "install_libs",
  },

  // ── ВЕТКА: БАЗОВЫЙ PYTHON ──────────────────────────────────────────────────
  basic_python: {
    id: "basic_python",
    type: "lesson",
    phase: "🛠 Подготовка",
    title: "Шаг 1. Проверяем окружение",
    text: "Убедимся, что всё настроено правильно перед стартом.",
    steps: [
      { n: 1, text: "Открой cmd или PowerShell и введи: `python --version`" },
      { n: 2, text: "Убедись, что версия **3.9 или выше** (лучше 3.11+)" },
      { n: 3, text: "Создай папку проекта: `mkdir vk_bot && cd vk_bot`" },
      { n: 4, text: "Создай виртуальное окружение: `python -m venv venv`" },
      { n: 5, text: "Активируй: `venv\\Scripts\\activate` (Windows) или `source venv/bin/activate` (Mac/Linux)" },
    ],
    tip: "💡 Виртуальное окружение изолирует библиотеки проекта — это хорошая практика.",
    next: "install_libs",
  },

  // ── ВЕТКА: ПРОДВИНУТЫЙ PYTHON ──────────────────────────────────────────────
  advanced_python: {
    id: "advanced_python",
    type: "lesson",
    phase: "🛠 Подготовка",
    title: "Шаг 1. Структура проекта",
    text: "Сразу сделаем всё по-взрослому — с правильной структурой.",
    steps: [
      { n: 1, text: "Создай папку: `mkdir vk_bot && cd vk_bot`" },
      { n: 2, text: "Инициализируй venv: `python -m venv venv && venv\\Scripts\\activate`" },
      { n: 3, text: "Создай файлы: `main.py`, `config.py`, `.env`, `.gitignore`" },
      { n: 4, text: "В `.gitignore` добавь: `.env` и `venv/` — чтобы не утекли токены" },
      { n: 5, text: "Создай `requirements.txt` — будем заполнять по ходу" },
    ],
    tip: "💡 Хорошая структура с самого начала сэкономит часы при отладке.",
    next: "install_libs",
  },

  // ── ОБЩАЯ ТОЧКА: УСТАНОВКА БИБЛИОТЕК ──────────────────────────────────────
  install_libs: {
    id: "install_libs",
    type: "lesson",
    phase: "🛠 Подготовка",
    title: "Устанавливаем библиотеки",
    text: "Это все зависимости, которые нам понадобятся. Одна команда — и готово.",
    steps: [
      { n: 1, text: "Открой терминал в папке проекта (или VS Code Terminal)" },
      {
        n: 2,
        text: "Выполни команду:",
        code: "pip install anthropic vk_api openai python-dotenv requests gspread python-telegram-bot schedule",
      },
      { n: 3, text: "Дождись установки — займёт 1–2 минуты" },
      { n: 4, text: "Проверь: `pip list` — в списке должны быть все установленные пакеты" },
    ],
    tip: "💡 Если появляется ошибка «pip не найден» — используй `python -m pip install ...`",
    next: "vk_token_intro",
  },

  // ── VK ТОКЕН ───────────────────────────────────────────────────────────────
  vk_token_intro: {
    id: "vk_token_intro",
    type: "question",
    phase: "🔑 VK API",
    title: "Настраиваем доступ к VK",
    text: "Для публикации постов нужен токен VK. Ты уже создавал приложение на dev.vk.com?",
    options: [
      { label: "Нет, буду делать впервые", value: "vk_token_new", icon: "🆕" },
      { label: "Да, токен уже есть", value: "vk_token_have", icon: "✅" },
    ],
  },

  vk_token_new: {
    id: "vk_token_new",
    type: "lesson",
    phase: "🔑 VK API",
    title: "Получаем токен VK",
    text: "Пошагово создадим приложение и получим токен с нужными правами.",
    steps: [
      { n: 1, text: "Открой **vk.com/apps** → нажми «Создать приложение»" },
      { n: 2, text: "Выбери тип **«Standalone-приложение»**, введи любое название (например, «VK Auto Poster»)" },
      { n: 3, text: "После создания запомни **ID приложения** (числовой, в настройках)" },
      {
        n: 4,
        text: "Открой в браузере этот URL (замени APP_ID на свой):",
        code: "https://oauth.vk.com/authorize?client_id=APP_ID&display=page&redirect_uri=https://oauth.vk.com/blank.html&scope=wall,photos,offline&response_type=token&v=5.131",
      },
      { n: 5, text: "Разреши доступ → в адресной строке появится `access_token=...`" },
      { n: 6, text: "Скопируй токен — он между `access_token=` и `&expires_in`" },
    ],
    tip: "⚠️ Токен — как пароль. Никому не передавай и не публикуй в коде.",
    next: "vk_token_have",
  },

  vk_token_have: {
    id: "vk_token_have",
    type: "lesson",
    phase: "🔑 VK API",
    title: "Сохраняем токен безопасно",
    text: "Токен нельзя хранить прямо в коде. Используем .env файл.",
    steps: [
      { n: 1, text: "В папке проекта создай файл `.env`" },
      {
        n: 2,
        text: "Добавь в него (замени на свои значения):",
        code: `VK_TOKEN=твой_токен_vk
ANTHROPIC_KEY=твой_ключ_claude
OPENAI_KEY=твой_ключ_openai
VK_GROUP_ID=id_твоего_сообщества`,
      },
      { n: 3, text: "Создай файл `config.py` с содержимым:" },
      {
        n: 4,
        text: "",
        code: `from dotenv import load_dotenv
import os

load_dotenv()

VK_TOKEN = os.getenv("VK_TOKEN")
ANTHROPIC_KEY = os.getenv("ANTHROPIC_KEY")
OPENAI_KEY = os.getenv("OPENAI_KEY")
VK_GROUP_ID = int(os.getenv("VK_GROUP_ID", "0"))`,
      },
      { n: 5, text: "Добавь `.env` в файл `.gitignore` — если используешь Git" },
    ],
    tip: "💡 VK_GROUP_ID — это число после `-` в ссылке на сообщество. Например, vk.com/club123456789 → ID = -123456789",
    next: "api_keys_intro",
  },

  // ── API КЛЮЧИ ──────────────────────────────────────────────────────────────
  api_keys_intro: {
    id: "api_keys_intro",
    type: "question",
    phase: "🔑 API-ключи",
    title: "Какие API ключи уже есть?",
    text: "Выбери свою ситуацию — покажу, где получить недостающее.",
    options: [
      { label: "Ни одного нет, всё новое", value: "keys_none", icon: "🌱" },
      { label: "Есть OpenAI, нет Anthropic", value: "keys_openai", icon: "🟡" },
      { label: "Все ключи уже есть", value: "first_script", icon: "✅" },
    ],
  },

  keys_none: {
    id: "keys_none",
    type: "lesson",
    phase: "🔑 API-ключи",
    title: "Получаем ключи Claude и OpenAI",
    text: "Нам нужны два ключа: Claude (для текста) и OpenAI (для картинок DALL·E).",
    steps: [
      { n: 1, text: "**Claude API:** открой **console.anthropic.com** → Sign up → API Keys → Create Key" },
      { n: 2, text: "Скопируй ключ (начинается на `sk-ant-...`) → вставь в `.env` как `ANTHROPIC_KEY`" },
      { n: 3, text: "**OpenAI:** открой **platform.openai.com** → Sign up → API Keys → Create new secret key" },
      { n: 4, text: "Скопируй ключ (начинается на `sk-...`) → вставь в `.env` как `OPENAI_KEY`" },
      { n: 5, text: "Пополни баланс: на Anthropic от $5, на OpenAI от $5 — этого хватит на месяцы тестов" },
    ],
    tip: "💡 На старте тебе хватит $2–3 на сотни постов. Claude Sonnet ≈ $0.003 за пост, DALL·E ≈ $0.04 за картинку.",
    next: "first_script",
  },

  keys_openai: {
    id: "keys_openai",
    type: "lesson",
    phase: "🔑 API-ключи",
    title: "Получаем ключ Claude",
    text: "OpenAI у тебя есть. Добавим Claude — он лучше пишет на русском.",
    steps: [
      { n: 1, text: "Открой **console.anthropic.com** → Sign up (или Log in)" },
      { n: 2, text: "Перейди в **API Keys** → **Create Key**" },
      { n: 3, text: "Скопируй ключ (начинается на `sk-ant-...`)" },
      { n: 4, text: "Вставь в `.env` как `ANTHROPIC_KEY=sk-ant-...`" },
      { n: 5, text: "Пополни баланс на $5 — хватит надолго" },
    ],
    tip: "💡 Claude особенно хорошо понимает нюансы русского языка и региональный контекст — важно для Кировской аудитории.",
    next: "first_script",
  },

  // ── ПЕРВЫЙ СКРИПТ ──────────────────────────────────────────────────────────
  first_script: {
    id: "first_script",
    type: "lesson",
    phase: "💻 MVP",
    title: "Пишем первый рабочий скрипт",
    text: "MVP — минимально работающая версия. Запускаешь вручную, он всё делает сам.",
    steps: [
      { n: 1, text: "Создай файл `main.py` в папке проекта" },
      { n: 2, text: "Вставь следующий код:" },
      {
        n: 3,
        text: "",
        code: `import vk_api
import requests
import time
from datetime import datetime
from openai import OpenAI
from anthropic import Anthropic
from config import VK_TOKEN, ANTHROPIC_KEY, OPENAI_KEY, VK_GROUP_ID

# Инициализация клиентов
claude = Anthropic(api_key=ANTHROPIC_KEY)
openai_client = OpenAI(api_key=OPENAI_KEY)
vk_session = vk_api.VkApi(token=VK_TOKEN)
vk = vk_session.get_api()

def generate_post_text():
    today = datetime.now().strftime("%A, %d %B %Y")
    response = claude.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=1000,
        messages=[{
            "role": "user",
            "content": f"""Сегодня {today}. Напиши пост для VK-сообщества 
о строительных материалах в Кировской области.
Аудитория: частные застройщики, прорабы, малый бизнес.
Тематика: бетон, щебень, песок, ПГС, пиломатериалы, аренда спецтехники.
Формат: 150-200 слов, живой язык, 2-3 эмодзи, призыв к действию в конце.
Также в конце добавь строку IMAGE_PROMPT: [промпт для DALL-E на английском]"""
        }]
    )
    return response.content[0].text

def generate_image(prompt):
    response = openai_client.images.generate(
        model="dall-e-3",
        prompt=prompt,
        size="1024x1024",
        quality="standard",
        n=1,
    )
    image_url = response.data[0].url
    img_data = requests.get(image_url).content
    with open("temp_image.jpg", "wb") as f:
        f.write(img_data)
    return "temp_image.jpg"

def upload_photo_to_vk(image_path):
    upload_server = vk.photos.getWallUploadServer(group_id=abs(VK_GROUP_ID))
    with open(image_path, "rb") as f:
        response = requests.post(upload_server["upload_url"], files={"photo": f}).json()
    saved = vk.photos.saveWallPhoto(
        group_id=abs(VK_GROUP_ID),
        photo=response["photo"],
        server=response["server"],
        hash=response["hash"]
    )
    return f"photo{saved[0]['owner_id']}_{saved[0]['id']}"

def publish_post(text, attachment):
    publish_time = int(time.time()) + 3600  # через 1 час
    vk.wall.post(
        owner_id=VK_GROUP_ID,
        message=text,
        attachments=attachment,
        publish_date=publish_time
    )
    print("✅ Пост добавлен в отложенные VK (выйдет через 1 час)")

# ЗАПУСК
if __name__ == "__main__":
    print("🚀 Генерирую контент...")
    full_text = generate_post_text()
    
    # Разбиваем текст и промпт для картинки
    if "IMAGE_PROMPT:" in full_text:
        parts = full_text.split("IMAGE_PROMPT:")
        post_text = parts[0].strip()
        img_prompt = parts[1].strip()
    else:
        post_text = full_text
        img_prompt = "construction materials, concrete, gravel, building site, professional photo"
    
    print(f"\\n📝 Текст поста:\\n{post_text}\\n")
    print(f"🎨 Генерирую изображение...")
    
    image_path = generate_image(img_prompt)
    attachment = upload_photo_to_vk(image_path)
    publish_post(post_text, attachment)`,
      },
      { n: 4, text: "Запусти скрипт: `python main.py`" },
      { n: 5, text: "Зайди в VK → Управление сообществом → Отложенные — пост должен быть там" },
    ],
    tip: "⚠️ Пост попадёт в отложенные, а не сразу публикуется — у тебя будет время его проверить и отменить.",
    next: "mvp_check",
  },

  mvp_check: {
    id: "mvp_check",
    type: "question",
    phase: "💻 MVP",
    title: "Как прошёл запуск?",
    text: "Запусти скрипт и выбери, что произошло:",
    options: [
      { label: "Всё сработало, пост в отложенных ✅", value: "mvp_success", icon: "🎉" },
      { label: "Ошибка с VK API", value: "error_vk", icon: "⚠️" },
      { label: "Ошибка с Claude или OpenAI", value: "error_ai", icon: "⚠️" },
      { label: "Другая ошибка / не понял что происходит", value: "error_other", icon: "🤔" },
    ],
  },

  error_vk: {
    id: "error_vk",
    type: "lesson",
    phase: "💻 MVP — отладка",
    title: "Решаем ошибку VK API",
    text: "Частые проблемы с VK и как их исправить:",
    steps: [
      { n: 1, text: "**«Invalid access token»** — токен устарел или неправильно скопирован. Пересоздай токен по инструкции выше." },
      { n: 2, text: "**«Access denied»** — у приложения нет прав. Убедись, что в URL для токена был параметр `scope=wall,photos,offline`." },
      { n: 3, text: "**«group_id not found»** — проверь VK_GROUP_ID: он должен быть отрицательным числом (`-123456789`), не положительным." },
      { n: 4, text: "**«Too many requests»** — подожди минуту и запусти снова." },
      { n: 5, text: "Для диагностики добавь в скрипт перед `vk.wall.post`: `print(vk.users.get())` — если вернулся твой профиль, токен рабочий." },
    ],
    tip: "💡 Ошибки VK API всегда содержат код ошибки (error_code). Погугли «VK API error [код]» — найдёшь решение за минуту.",
    next: "mvp_check",
  },

  error_ai: {
    id: "error_ai",
    type: "lesson",
    phase: "💻 MVP — отладка",
    title: "Решаем ошибку AI API",
    text: "Проблемы с Claude или OpenAI:",
    steps: [
      { n: 1, text: "**«AuthenticationError»** — неправильный API ключ. Проверь .env файл, нет ли лишних пробелов." },
      { n: 2, text: "**«InsufficientQuotaError»** — нет денег на балансе. Пополни аккаунт на platform.openai.com или console.anthropic.com." },
      { n: 3, text: "**«RateLimitError»** — слишком много запросов. Подожди минуту." },
      { n: 4, text: "Для проверки Claude добавь в начало скрипта тест:" },
      {
        n: 5,
        text: "",
        code: `# Тест Claude
test = claude.messages.create(
    model="claude-sonnet-4-5",
    max_tokens=50,
    messages=[{"role": "user", "content": "Скажи 'OK'"}]
)
print(test.content[0].text)  # Должно вывести OK`,
      },
    ],
    tip: "💡 Проверяй каждый компонент по отдельности — так быстрее найдёшь проблему.",
    next: "mvp_check",
  },

  error_other: {
    id: "error_other",
    type: "lesson",
    phase: "💻 MVP — отладка",
    title: "Общая отладка",
    text: "Разберём по шагам, что могло пойти не так:",
    steps: [
      { n: 1, text: "Скопируй полный текст ошибки из терминала" },
      { n: 2, text: "Проверь: все ли файлы на месте? (`config.py`, `.env`, `main.py` в одной папке?)" },
      { n: 3, text: "Убедись, что виртуальное окружение активировано (в терминале слева должно быть `(venv)`)" },
      { n: 4, text: "Повтори установку библиотек: `pip install anthropic vk_api openai python-dotenv requests`" },
      { n: 5, text: "Если ошибка типа `ModuleNotFoundError: No module named 'X'` — установи недостающий модуль: `pip install X`" },
    ],
    tip: "💡 Вставь текст ошибки в Claude или ChatGPT — AI отлично диагностирует ошибки Python.",
    next: "mvp_check",
  },

  // ── MVP УСПЕХ ──────────────────────────────────────────────────────────────
  mvp_success: {
    id: "mvp_success",
    type: "question",
    phase: "🤖 Telegram-бот",
    title: "Отлично! Переходим к автоматизации",
    text: "MVP работает. Теперь — добавить Telegram-уведомления для контроля. Есть ли у тебя Telegram-бот?",
    options: [
      { label: "Нет, создам сейчас", value: "tg_create", icon: "🆕" },
      { label: "Уже есть свой бот", value: "tg_have", icon: "✅" },
      { label: "Хочу пропустить Telegram и сразу к планировщику", value: "scheduler", icon: "⏭" },
    ],
  },

  tg_create: {
    id: "tg_create",
    type: "lesson",
    phase: "🤖 Telegram-бот",
    title: "Создаём Telegram-бот",
    text: "Бот нужен, чтобы ты получал превью постов и мог их одобрить нажатием кнопки.",
    steps: [
      { n: 1, text: "Открой Telegram → найди **@BotFather**" },
      { n: 2, text: "Напиши `/newbot` → придумай имя (например, «VK Auto Poster») и username (например, `myvk_poster_bot`)" },
      { n: 3, text: "BotFather пришлёт **токен** вида `7123456789:AAF...` — скопируй его" },
      { n: 4, text: "Добавь в `.env`: `TG_BOT_TOKEN=твой_токен_бота`" },
      { n: 5, text: "Теперь узнай свой Chat ID: найди в Telegram бота **@userinfobot**, напиши ему `/start` — он покажет твой ID" },
      { n: 6, text: "Добавь в `.env`: `TG_CHAT_ID=твой_chat_id`" },
    ],
    tip: "💡 Chat ID — это число (может быть отрицательным для групп). Именно на него бот будет слать уведомления.",
    next: "tg_have",
  },

  tg_have: {
    id: "tg_have",
    type: "lesson",
    phase: "🤖 Telegram-бот",
    title: "Добавляем подтверждение через Telegram",
    text: "Обновим скрипт: теперь перед публикацией ты будешь получать превью и кнопки одобрения.",
    steps: [
      { n: 1, text: "Добавь в `config.py`:" },
      {
        n: 2,
        text: "",
        code: `TG_BOT_TOKEN = os.getenv("TG_BOT_TOKEN")
TG_CHAT_ID = int(os.getenv("TG_CHAT_ID", "0"))`,
      },
      { n: 3, text: "Создай файл `telegram_notify.py`:" },
      {
        n: 4,
        text: "",
        code: `import asyncio
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CallbackQueryHandler
from config import TG_BOT_TOKEN, TG_CHAT_ID

bot = Bot(token=TG_BOT_TOKEN)

async def send_preview(text, image_path):
    """Отправляет превью поста с кнопками одобрения"""
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Опубликовать", callback_data="approve"),
            InlineKeyboardButton("❌ Отклонить", callback_data="reject"),
        ]
    ])
    caption = f"📋 *Превью поста:*\\n\\n{text[:1000]}..."
    with open(image_path, "rb") as photo:
        msg = await bot.send_photo(
            chat_id=TG_CHAT_ID,
            photo=photo,
            caption=caption,
            parse_mode="Markdown",
            reply_markup=keyboard
        )
    return msg.message_id

async def wait_for_approval(timeout_seconds=7200):
    """Ждём ответа. Если нет — автоодобрение через 2 часа"""
    # Упрощённая версия: используем webhook или polling
    # Для MVP просто уведомляем и публикуем через N секунд
    await asyncio.sleep(30)  # Заглушка — замени на реальный polling
    return True  # approved`,
      },
      { n: 5, text: "Добавь вызов `send_preview` в `main.py` перед публикацией — отправь себе превью" },
    ],
    tip: "💡 Для полноценного interactive бота с кнопками потребуется чуть больше кода — покажу на следующем шаге.",
    next: "scheduler",
  },

  // ── ПЛАНИРОВЩИК ───────────────────────────────────────────────────────────
  scheduler: {
    id: "scheduler",
    type: "question",
    phase: "⏰ Планировщик",
    title: "Как ты хочешь запускать скрипт?",
    text: "Выбери способ автоматического запуска. Это определит надёжность системы.",
    options: [
      { label: "Просто запускать вручную каждое утро", value: "manual_run", icon: "👆" },
      { label: "Планировщик Windows (Task Scheduler) — просто", value: "windows_scheduler", icon: "🖥" },
      { label: "n8n — визуальный, надёжный, гибкий", value: "n8n_setup", icon: "⚙️" },
    ],
  },

  manual_run: {
    id: "manual_run",
    type: "lesson",
    phase: "⏰ Запуск",
    title: "Ручной запуск — это нормально для старта",
    text: "На первые 1–2 недели это лучший вариант: ты держишь руку на пульсе.",
    steps: [
      { n: 1, text: "Создай `.bat` файл `run_daily.bat` рядом со скриптами:" },
      {
        n: 2,
        text: "",
        code: `@echo off
cd /d C:\\Users\\ТвоёИмя\\Desktop\\vk_bot
call venv\\Scripts\\activate
python main.py
pause`,
      },
      { n: 3, text: "Каждое утро просто дважды кликаешь на `run_daily.bat`" },
      { n: 4, text: "Терминал покажет прогресс, в конце — результат" },
      { n: 5, text: "Когда наберёшь уверенности — переходи к планировщику Windows" },
    ],
    tip: "💡 Pause в конце .bat файла нужна, чтобы окно не закрывалось сразу — ты успеешь прочитать результат.",
    next: "content_plan",
  },

  windows_scheduler: {
    id: "windows_scheduler",
    type: "lesson",
    phase: "⏰ Планировщик",
    title: "Настраиваем Планировщик Windows",
    text: "Скрипт будет запускаться автоматически каждый день в заданное время.",
    steps: [
      { n: 1, text: "Нажми Win+R → введи `taskschd.msc` → Enter" },
      { n: 2, text: "«Создать простую задачу» → дай название «VK Auto Post»" },
      { n: 3, text: "Триггер: «Ежедневно», время: **08:00**" },
      { n: 4, text: "Действие: «Запустить программу»" },
      {
        n: 5,
        text: "Параметры программы:",
        code: `Программа: C:\\Users\\ТвоёИмя\\Desktop\\vk_bot\\venv\\Scripts\\python.exe
Аргументы: main.py
Папка: C:\\Users\\ТвоёИмя\\Desktop\\vk_bot`,
      },
      { n: 6, text: "Готово! Задача будет запускаться ежедневно в 08:00, даже если ты не за компьютером (при включённом ПК)" },
    ],
    tip: "⚠️ Компьютер должен быть включён в 08:00. Если часто выключаешь — рассмотри n8n на облаке или VPS.",
    next: "content_plan",
  },

  n8n_setup: {
    id: "n8n_setup",
    type: "lesson",
    phase: "⏰ n8n",
    title: "Устанавливаем n8n",
    text: "n8n — это визуальный оркестратор процессов. Работает как конструктор: соединяешь блоки мышью.",
    steps: [
      { n: 1, text: "Установи Docker Desktop: **docker.com/products/docker-desktop**" },
      { n: 2, text: "После установки запусти Docker Desktop и дождись зелёного статуса" },
      {
        n: 3,
        text: "В терминале выполни:",
        code: `docker run -it --rm --name n8n -p 5678:5678 -v n8n_data:/home/node/.n8n docker.n8n.io/n8nio/n8n`,
      },
      { n: 4, text: "Открой браузер: **http://localhost:5678** — увидишь интерфейс n8n" },
      { n: 5, text: "Создай первый workflow: нажми «New Workflow» → добавь узел «Schedule Trigger» → настрой на 08:00 ежедневно" },
      { n: 6, text: "Добавь узел «HTTP Request» → подключи к Claude API → добавь ещё один для VK API" },
    ],
    tip: "💡 n8n сохраняет состояние между запусками, показывает историю выполнений и логи ошибок. Это на порядок надёжнее простого cron.",
    next: "content_plan",
  },

  // ── КОНТЕНТ-ПЛАН ──────────────────────────────────────────────────────────
  content_plan: {
    id: "content_plan",
    type: "lesson",
    phase: "📅 Контент-план",
    title: "Создаём Google Sheets контент-план",
    text: "Таблица будет источником тем. Скрипт будет брать тему на сегодня и передавать в промпт.",
    steps: [
      { n: 1, text: "Создай новый Google Sheets" },
      {
        n: 2,
        text: "Сделай такую структуру (первая строка — заголовки):",
        code: `Дата | Тема | Тип контента | Доп. контекст | Статус | ID поста VK`,
      },
      { n: 3, text: "Заполни темы на 2–4 недели вперёд. Например:" },
      {
        n: 4,
        text: "",
        code: `09.06 | Бетон М300 — для чего подходит | Полезное | Частные дома, фундаменты | — | —
10.06 | Аренда экскаватора — цены и условия | Товар/услуга | — | — | —
11.06 | Как выбрать щебень для отсыпки дороги | Полезное | — | — | —`,
      },
      { n: 5, text: "Открой доступ к таблице через API: Google Cloud Console → APIs → Google Sheets API → включи" },
      { n: 6, text: "Создай сервисный аккаунт → скачай JSON-ключ → добавь в папку проекта как `google_creds.json`" },
      { n: 7, text: "Добавь email сервисного аккаунта в соавторы таблицы (кнопка «Поделиться»)" },
    ],
    tip: "💡 Формат даты в таблице должен совпадать с тем, что ты передаёшь в скрипт. Используй `dd.mm.yyyy` или ISO `2024-06-09`.",
    next: "sheets_integration",
  },

  sheets_integration: {
    id: "sheets_integration",
    type: "lesson",
    phase: "📅 Контент-план",
    title: "Подключаем скрипт к Google Sheets",
    text: "Добавим чтение темы дня из таблицы вместо статичного промпта.",
    steps: [
      { n: 1, text: "Создай файл `sheets_helper.py`:" },
      {
        n: 2,
        text: "",
        code: `import gspread
from datetime import datetime

def get_todays_topic():
    gc = gspread.service_account(filename="google_creds.json")
    sh = gc.open("VK Content Plan")  # Название твоей таблицы
    ws = sh.sheet1
    
    today = datetime.now().strftime("%d.%m")  # формат: 09.06
    records = ws.get_all_records()
    
    for row in records:
        if str(row["Дата"]).startswith(today):
            return {
                "topic": row["Тема"],
                "type": row["Тип контента"],
                "context": row.get("Доп. контекст", "")
            }
    
    return {"topic": "Общая тема о строительных материалах", "type": "Полезное", "context": ""}`,
      },
      { n: 3, text: "В `main.py` замени статичный промпт на динамический:" },
      {
        n: 4,
        text: "",
        code: `from sheets_helper import get_todays_topic

topic_data = get_todays_topic()
# Используй topic_data["topic"] в промпте для Claude`,
      },
    ],
    tip: "💡 Теперь достаточно заполнить таблицу на месяц вперёд — система сама возьмёт нужную тему.",
    next: "logging",
  },

  // ── ЛОГИРОВАНИЕ ───────────────────────────────────────────────────────────
  logging: {
    id: "logging",
    type: "lesson",
    phase: "📊 Логирование",
    title: "Добавляем логирование",
    text: "Чтобы знать, что и когда было опубликовано, и собирать статистику позже.",
    steps: [
      { n: 1, text: "Создай файл `logger.py`:" },
      {
        n: 2,
        text: "",
        code: `import sqlite3
from datetime import datetime

def init_db():
    conn = sqlite3.connect("posts.db")
    conn.execute("""CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        topic TEXT,
        post_text TEXT,
        vk_post_id TEXT,
        status TEXT,
        likes INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.commit()
    conn.close()

def log_post(topic, post_text, vk_post_id, status="published"):
    conn = sqlite3.connect("posts.db")
    conn.execute(
        "INSERT INTO posts (date, topic, post_text, vk_post_id, status) VALUES (?,?,?,?,?)",
        (datetime.now().strftime("%Y-%m-%d"), topic, post_text, vk_post_id, status)
    )
    conn.commit()
    conn.close()

def get_recent_posts(n=5):
    conn = sqlite3.connect("posts.db")
    cursor = conn.execute("SELECT topic, post_text FROM posts ORDER BY id DESC LIMIT ?", (n,))
    posts = cursor.fetchall()
    conn.close()
    return posts`,
      },
      { n: 3, text: "В `main.py` добавь: `from logger import init_db, log_post, get_recent_posts`" },
      { n: 4, text: "В начале main добавь `init_db()` — создаст БД при первом запуске" },
      { n: 5, text: "После публикации добавь `log_post(topic, post_text, vk_post_id)`" },
    ],
    tip: "💡 История последних постов из `get_recent_posts()` передаётся в промпт Клода — это помогает избегать повторов.",
    next: "analytics",
  },

  // ── АНАЛИТИКА ─────────────────────────────────────────────────────────────
  analytics: {
    id: "analytics",
    type: "question",
    phase: "📊 Аналитика",
    title: "Система работает. Добавляем аналитику?",
    text: "Сбор статистики по постам позволит понять, какой контент работает лучше.",
    options: [
      { label: "Да, хочу знать охваты и лайки", value: "analytics_yes", icon: "📈" },
      { label: "Пока достаточно, хочу финальный итог", value: "final", icon: "🏁" },
    ],
  },

  analytics_yes: {
    id: "analytics_yes",
    type: "lesson",
    phase: "📊 Аналитика",
    title: "Сбор статистики через VK API",
    text: "Добавим скрипт, который собирает лайки, репосты и охваты через день после публикации.",
    steps: [
      { n: 1, text: "Создай файл `stats_collector.py`:" },
      {
        n: 2,
        text: "",
        code: `import sqlite3
import vk_api
from config import VK_TOKEN, VK_GROUP_ID

vk_session = vk_api.VkApi(token=VK_TOKEN)
vk = vk_session.get_api()

def collect_stats():
    conn = sqlite3.connect("posts.db")
    # Берём посты без статистики старше 24 часов
    cursor = conn.execute("""
        SELECT id, vk_post_id FROM posts 
        WHERE likes = 0 
        AND datetime(created_at) < datetime('now', '-1 day')
        AND vk_post_id IS NOT NULL
    """)
    posts_to_update = cursor.fetchall()
    
    for post_id, vk_post_id in posts_to_update:
        try:
            stats = vk.wall.getById(posts=f"{VK_GROUP_ID}_{vk_post_id}")
            if stats:
                post = stats[0]
                likes = post.get("likes", {}).get("count", 0)
                views = post.get("views", {}).get("count", 0)
                reposts = post.get("reposts", {}).get("count", 0)
                
                conn.execute(
                    "UPDATE posts SET likes=?, views=? WHERE id=?",
                    (likes, views, post_id)
                )
                print(f"Post {vk_post_id}: 👍{likes} 👁{views} 🔄{reposts}")
        except Exception as e:
            print(f"Ошибка для поста {vk_post_id}: {e}")
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    collect_stats()`,
      },
      { n: 3, text: "Добавь запуск `stats_collector.py` в Планировщик Windows — каждый день в 10:00 (через 2 часа после публикации)" },
      { n: 4, text: "Лучшие посты передавай в промпт Клода как пример стиля:" },
      {
        n: 5,
        text: "",
        code: `# В main.py при генерации промпта
top_posts = get_top_posts_by_views(n=3)  # добавь эту функцию в logger.py
context = f"Лучшие посты по охвату: {top_posts}"`,
      },
    ],
    tip: "💡 Анализ за 2–3 недели покажет, какие темы и форматы работают лучше всего для твоей аудитории.",
    next: "final",
  },

  // ── ФИНАЛ ─────────────────────────────────────────────────────────────────
  final: {
    id: "final",
    type: "final",
    phase: "🏁 Готово",
    title: "Система готова к работе!",
    text: "Ты прошёл весь путь от нуля до автоматизированной публикации в VK. Вот что ты построил:",
    summary: [
      "✅ Python-окружение и все необходимые библиотеки",
      "✅ Безопасное хранение токенов VK, Claude и OpenAI",
      "✅ MVP-скрипт: дата → Claude → картинка → VK (отложенные)",
      "✅ Telegram-уведомления с превью и кнопками",
      "✅ Google Sheets с расписанием тем на месяц",
      "✅ Автозапуск по расписанию",
      "✅ SQLite база логов всех постов",
      "✅ Сбор статистики для улучшения контента",
    ],
    nextSteps: [
      "📌 Следующий уровень: переехать с Python-скрипта на n8n для надёжности",
      "📌 Добавить A/B тестирование заголовков",
      "📌 Подключить локальную генерацию изображений через ComfyUI (если есть GPU)",
      "📌 Настроить еженедельный отчёт в Telegram с топ-постами",
    ],
  },
};

// ─── COMPONENT ────────────────────────────────────────────────────────────────

const PHASE_COLORS = {
  "🔍 Диагностика": "#C9A84C",
  "🛠 Подготовка": "#7C9E6E",
  "🔑 VK API": "#6E7C9E",
  "🔑 API-ключи": "#6E7C9E",
  "💻 MVP": "#9E6E6E",
  "💻 MVP — отладка": "#B87070",
  "🤖 Telegram-бот": "#9E6E9E",
  "⏰ Планировщик": "#6E9E9E",
  "⏰ Запуск": "#6E9E9E",
  "⏰ n8n": "#6E9E9E",
  "📅 Контент-план": "#9E9E6E",
  "📊 Логирование": "#7E8E9E",
  "📊 Аналитика": "#7E8E9E",
  "🏁 Готово": "#C9A84C",
};

function CodeBlock({ code }) {
  const [copied, setCopied] = useState(false);
  return (
    <div style={{ position: "relative", margin: "10px 0" }}>
      <pre style={{
        background: "#0D1117",
        border: "1px solid #30363D",
        borderRadius: 8,
        padding: "14px 16px",
        fontSize: 12,
        lineHeight: 1.6,
        color: "#E6EDF3",
        overflowX: "auto",
        fontFamily: "'Fira Code', 'Cascadia Code', 'Consolas', monospace",
      }}>
        <code>{code}</code>
      </pre>
      <button
        onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
        style={{
          position: "absolute", top: 8, right: 8,
          background: copied ? "#238636" : "#21262D",
          border: "1px solid #30363D",
          borderRadius: 6,
          color: "#8B949E",
          fontSize: 11,
          padding: "3px 10px",
          cursor: "pointer",
          transition: "all .2s",
        }}
      >
        {copied ? "✓ Скопировано" : "Копировать"}
      </button>
    </div>
  );
}

function renderText(text) {
  if (!text) return null;
  return text.split("**").map((part, i) =>
    i % 2 === 1 ? <strong key={i} style={{ color: "#F0C674" }}>{part}</strong> : part
  );
}

function ProgressBar({ visited }) {
  const total = Object.keys(STEPS).length;
  const pct = Math.round((visited.size / total) * 100);
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 12, color: "#8B949E" }}>
        <span>Прогресс</span>
        <span>{pct}%</span>
      </div>
      <div style={{ height: 4, background: "#21262D", borderRadius: 4, overflow: "hidden" }}>
        <div style={{
          height: "100%",
          width: `${pct}%`,
          background: "linear-gradient(90deg, #C9A84C, #F0C674)",
          borderRadius: 4,
          transition: "width .5s ease",
        }} />
      </div>
    </div>
  );
}

export default function App() {
  const [currentId, setCurrentId] = useState("start");
  const [history, setHistory] = useState(["start"]);
  const [visited, setVisited] = useState(new Set(["start"]));
  const [expandedSteps, setExpandedSteps] = useState({});
  const topRef = useRef(null);

  const step = STEPS[currentId];
  const phaseColor = PHASE_COLORS[step?.phase] || "#C9A84C";

  const goTo = (id) => {
    if (!STEPS[id]) return;
    setCurrentId(id);
    setHistory(h => [...h, id]);
    setVisited(v => new Set([...v, id]));
    setTimeout(() => topRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  const goBack = () => {
    if (history.length < 2) return;
    const newHistory = history.slice(0, -1);
    setHistory(newHistory);
    setCurrentId(newHistory[newHistory.length - 1]);
    setTimeout(() => topRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  useEffect(() => {
    setExpandedSteps({});
  }, [currentId]);

  if (!step) return <div style={{ color: "#fff", padding: 40 }}>Шаг не найден: {currentId}</div>;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0D1117",
      fontFamily: "'IBM Plex Sans', 'Segoe UI', sans-serif",
      color: "#E6EDF3",
      padding: "0 0 80px",
    }}>
      {/* Header */}
      <div style={{
        background: "#161B22",
        borderBottom: "1px solid #21262D",
        padding: "16px 20px",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}>
        <div style={{ maxWidth: 680, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <div style={{
              width: 32, height: 32,
              background: "linear-gradient(135deg, #C9A84C, #8B6914)",
              borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>⚙</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#F0C674", letterSpacing: 0.5 }}>VK Automation Course</div>
              <div style={{ fontSize: 11, color: "#6E7681" }}>Пошаговое обучение — Антон Махнёв</div>
            </div>
          </div>
          <ProgressBar visited={visited} />
        </div>
      </div>

      {/* Main */}
      <div style={{ maxWidth: 680, margin: "0 auto", padding: "24px 20px" }}>
        <div ref={topRef} />

        {/* Phase badge */}
        <div style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          background: `${phaseColor}20`,
          border: `1px solid ${phaseColor}50`,
          borderRadius: 20,
          padding: "4px 12px",
          fontSize: 12,
          color: phaseColor,
          marginBottom: 16,
          fontWeight: 600,
        }}>
          {step.phase}
        </div>

        {/* Card */}
        <div style={{
          background: "#161B22",
          border: "1px solid #21262D",
          borderRadius: 12,
          overflow: "hidden",
          marginBottom: 20,
        }}>
          {/* Card header */}
          <div style={{
            padding: "20px 24px 16px",
            borderBottom: "1px solid #21262D",
            background: `linear-gradient(135deg, #161B22 0%, ${phaseColor}08 100%)`,
          }}>
            <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: "#F0C674", lineHeight: 1.3 }}>
              {step.title}
            </h2>
            {step.text && (
              <p style={{ margin: "8px 0 0", fontSize: 14, color: "#8B949E", lineHeight: 1.6 }}>
                {renderText(step.text)}
              </p>
            )}
          </div>

          {/* LESSON */}
          {step.type === "lesson" && (
            <div style={{ padding: "20px 24px" }}>
              {step.steps && step.steps.map((s, i) => (
                <div key={i} style={{
                  display: "flex",
                  gap: 14,
                  marginBottom: s.code ? 6 : 12,
                  alignItems: "flex-start",
                }}>
                  <div style={{
                    minWidth: 26, height: 26,
                    background: `${phaseColor}30`,
                    border: `1px solid ${phaseColor}60`,
                    borderRadius: "50%",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 12, fontWeight: 700, color: phaseColor,
                    marginTop: 1,
                  }}>
                    {s.n}
                  </div>
                  <div style={{ flex: 1 }}>
                    {s.text && (
                      <div style={{ fontSize: 14, color: "#C9D1D9", lineHeight: 1.6 }}>
                        {renderText(s.text)}
                      </div>
                    )}
                    {s.code && <CodeBlock code={s.code} />}
                  </div>
                </div>
              ))}

              {step.tip && (
                <div style={{
                  marginTop: 16,
                  padding: "12px 16px",
                  background: "#1C2128",
                  border: "1px solid #2D333B",
                  borderLeft: `3px solid ${phaseColor}`,
                  borderRadius: 8,
                  fontSize: 13,
                  color: "#8B949E",
                  lineHeight: 1.6,
                }}>
                  {renderText(step.tip)}
                </div>
              )}

              {step.next && (
                <button
                  onClick={() => goTo(step.next)}
                  style={{
                    marginTop: 20,
                    width: "100%",
                    padding: "14px 20px",
                    background: `linear-gradient(135deg, ${phaseColor}30, ${phaseColor}15)`,
                    border: `1px solid ${phaseColor}60`,
                    borderRadius: 10,
                    color: phaseColor,
                    fontSize: 15,
                    fontWeight: 700,
                    cursor: "pointer",
                    transition: "all .2s",
                    letterSpacing: 0.3,
                  }}
                  onMouseEnter={e => e.target.style.background = `${phaseColor}40`}
                  onMouseLeave={e => e.target.style.background = `linear-gradient(135deg, ${phaseColor}30, ${phaseColor}15)`}
                >
                  Следующий шаг →
                </button>
              )}
            </div>
          )}

          {/* QUESTION */}
          {step.type === "question" && (
            <div style={{ padding: "20px 24px" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {step.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => goTo(opt.value)}
                    style={{
                      display: "flex", alignItems: "center", gap: 14,
                      padding: "14px 18px",
                      background: "#1C2128",
                      border: "1px solid #2D333B",
                      borderRadius: 10,
                      color: "#C9D1D9",
                      fontSize: 14,
                      cursor: "pointer",
                      textAlign: "left",
                      transition: "all .2s",
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.background = `${phaseColor}15`;
                      e.currentTarget.style.borderColor = `${phaseColor}50`;
                      e.currentTarget.style.color = "#F0C674";
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = "#1C2128";
                      e.currentTarget.style.borderColor = "#2D333B";
                      e.currentTarget.style.color = "#C9D1D9";
                    }}
                  >
                    <span style={{ fontSize: 20, minWidth: 28 }}>{opt.icon}</span>
                    <span style={{ fontWeight: 500 }}>{opt.label}</span>
                    <span style={{ marginLeft: "auto", color: "#4A505A", fontSize: 16 }}>›</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* FINAL */}
          {step.type === "final" && (
            <div style={{ padding: "20px 24px" }}>
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#7EE787", marginBottom: 10, letterSpacing: 0.5 }}>
                  ЧТО ПОСТРОЕНО
                </div>
                {step.summary.map((item, i) => (
                  <div key={i} style={{
                    padding: "8px 12px",
                    marginBottom: 6,
                    background: "#12261B",
                    border: "1px solid #1E3A27",
                    borderRadius: 8,
                    fontSize: 13,
                    color: "#7EE787",
                    lineHeight: 1.5,
                  }}>
                    {item}
                  </div>
                ))}
              </div>

              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: phaseColor, marginBottom: 10, letterSpacing: 0.5 }}>
                  СЛЕДУЮЩИЙ УРОВЕНЬ
                </div>
                {step.nextSteps.map((item, i) => (
                  <div key={i} style={{
                    padding: "8px 12px",
                    marginBottom: 6,
                    background: `${phaseColor}10`,
                    border: `1px solid ${phaseColor}30`,
                    borderRadius: 8,
                    fontSize: 13,
                    color: "#C9D1D9",
                    lineHeight: 1.5,
                  }}>
                    {item}
                  </div>
                ))}
              </div>

              <button
                onClick={() => { setCurrentId("start"); setHistory(["start"]); setVisited(new Set(["start"])); }}
                style={{
                  marginTop: 20,
                  width: "100%",
                  padding: "14px",
                  background: "transparent",
                  border: `1px solid ${phaseColor}50`,
                  borderRadius: 10,
                  color: phaseColor,
                  fontSize: 14,
                  cursor: "pointer",
                }}
              >
                🔄 Начать заново
              </button>
            </div>
          )}
        </div>

        {/* Back button */}
        {history.length > 1 && (
          <button
            onClick={goBack}
            style={{
              background: "transparent",
              border: "1px solid #2D333B",
              borderRadius: 8,
              color: "#6E7681",
              fontSize: 13,
              padding: "8px 16px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            ← Назад
          </button>
        )}
      </div>
    </div>
  );
}
